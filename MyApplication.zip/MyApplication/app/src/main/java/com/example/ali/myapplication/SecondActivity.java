package com.example.ali.myapplication;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Created by Ali on 7/12/2017.
 */

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.btn_activity);

    }

}
