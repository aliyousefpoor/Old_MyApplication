package com.example.ali.myapplication;

/**
 * Created by Ali on 7/15/2017.
 */

public class Data {
    public String title;
    public String description;
    public int imageId;

    Data(String title, String description, int imageId) {
        this.title = title;
        this.description = description;
        this.imageId = imageId;
    }

}